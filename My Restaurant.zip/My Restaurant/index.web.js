import React from 'react';
import ReactDOM from 'react-dom';
import App from './web/App';

ReactDOM.render(<App />, document.getElementById('index'));
